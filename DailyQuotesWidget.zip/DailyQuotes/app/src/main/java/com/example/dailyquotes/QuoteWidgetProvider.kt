package com.example.dailyquotes

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class QuoteWidgetProvider : AppWidgetProvider() {

    companion object {
        const val ACTION_NEXT_QUOTE = "com.example.dailyquotes.ACTION_NEXT_QUOTE"

        fun updateAppWidget(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int) {
            val quotes = QuoteStore.getQuotes(context)
            val index = QuoteStore.currentDisplayIndex(context)
            val text = if (quotes.isNotEmpty()) quotes[index % quotes.size] else "Add your sayings in the app."

            val views = RemoteViews(context.packageName, R.layout.widget_quote)
            views.setTextViewText(R.id.widget_quote_text, "\u201C$text\u201D")
            views.setTextViewText(
                R.id.widget_quote_number,
                if (quotes.isNotEmpty()) "${(index % quotes.size) + 1} / ${quotes.size} \u00B7 tap for another"
                else "tap to open"
            )

            // Tapping the widget cycles to the next saying.
            val intent = Intent(context, QuoteWidgetProvider::class.java).apply {
                action = ACTION_NEXT_QUOTE
            }
            val pendingIntent = PendingIntent.getBroadcast(
                context, appWidgetId, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_quote_text, pendingIntent)
            views.setOnClickPendingIntent(R.id.widget_quote_number, pendingIntent)

            appWidgetManager.updateAppWidget(appWidgetId, views)
        }
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        // Each scheduled update (roughly every 30 min, and on reboot/day change) re-syncs to today's saying.
        QuoteStore.resetManualIndexToToday(context)
        for (id in appWidgetIds) {
            updateAppWidget(context, appWidgetManager, id)
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_NEXT_QUOTE) {
            QuoteStore.nextManualIndex(context)
            val appWidgetManager = AppWidgetManager.getInstance(context)
            val ids = appWidgetManager.getAppWidgetIds(
                android.content.ComponentName(context, QuoteWidgetProvider::class.java)
            )
            for (id in ids) {
                updateAppWidget(context, appWidgetManager, id)
            }
        }
    }
}
