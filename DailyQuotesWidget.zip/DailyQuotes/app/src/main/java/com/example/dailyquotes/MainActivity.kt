package com.example.dailyquotes

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val editText = findViewById<EditText>(R.id.quotes_edit_text)
        val saveButton = findViewById<Button>(R.id.save_button)
        val resetButton = findViewById<Button>(R.id.reset_button)
        val statusText = findViewById<TextView>(R.id.status_text)

        editText.setText(QuoteStore.getQuotesAsText(this))

        saveButton.setOnClickListener {
            val text = editText.text.toString()
            val count = text.lines().map { it.trim() }.filter { it.isNotEmpty() }.size
            QuoteStore.saveQuotes(this, text)
            QuoteStore.resetManualIndexToToday(this)
            refreshAllWidgets()
            statusText.text = "Saved $count sayings. Your widget will update shortly."
        }

        resetButton.setOnClickListener {
            QuoteStore.resetToDefaults(this)
            editText.setText(QuoteStore.getQuotesAsText(this))
            refreshAllWidgets()
            statusText.text = "Reset to the built-in placeholder sayings."
        }
    }

    private fun refreshAllWidgets() {
        val appWidgetManager = AppWidgetManager.getInstance(this)
        val component = ComponentName(this, QuoteWidgetProvider::class.java)
        val ids = appWidgetManager.getAppWidgetIds(component)
        for (id in ids) {
            QuoteWidgetProvider.updateAppWidget(this, appWidgetManager, id)
        }
    }
}
