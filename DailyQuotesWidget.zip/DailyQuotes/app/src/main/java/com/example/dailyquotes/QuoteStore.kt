package com.example.dailyquotes

import android.content.Context
import java.util.Calendar

/**
 * Simple storage for the user's list of sayings.
 * Quotes are stored as newline-separated text in SharedPreferences
 * so they're easy to edit from MainActivity.
 */
object QuoteStore {

    private const val PREFS = "daily_quotes_prefs"
    private const val KEY_QUOTES = "quotes_text"
    private const val KEY_MANUAL_INDEX = "manual_index"

    fun getQuotes(context: Context): List<String> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val saved = prefs.getString(KEY_QUOTES, null)
        val text = saved ?: context.resources.getStringArray(R.array.default_quotes).joinToString("\n")
        return text.lines().map { it.trim() }.filter { it.isNotEmpty() }
    }

    fun getQuotesAsText(context: Context): String {
        return getQuotes(context).joinToString("\n")
    }

    fun saveQuotes(context: Context, rawText: String) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_QUOTES, rawText).apply()
    }

    fun resetToDefaults(context: Context) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.edit().remove(KEY_QUOTES).remove(KEY_MANUAL_INDEX).apply()
    }

    /** Index for "today" — same quote all day, changes automatically at midnight. */
    fun todaysIndex(context: Context): Int {
        val quotes = getQuotes(context)
        if (quotes.isEmpty()) return 0
        val dayOfYear = Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
        val year = Calendar.getInstance().get(Calendar.YEAR)
        return ((dayOfYear + year) % quotes.size)
    }

    /** Advances the manual override used by the "tap to see another" action. */
    fun nextManualIndex(context: Context): Int {
        val quotes = getQuotes(context)
        if (quotes.isEmpty()) return 0
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val current = prefs.getInt(KEY_MANUAL_INDEX, todaysIndex(context))
        val next = (current + 1) % quotes.size
        prefs.edit().putInt(KEY_MANUAL_INDEX, next).apply()
        return next
    }

    fun currentDisplayIndex(context: Context): Int {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return prefs.getInt(KEY_MANUAL_INDEX, todaysIndex(context))
    }

    /** Call this once a day (or whenever quotes are saved) to re-sync the manual index to "today". */
    fun resetManualIndexToToday(context: Context) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.edit().putInt(KEY_MANUAL_INDEX, todaysIndex(context)).apply()
    }
}
